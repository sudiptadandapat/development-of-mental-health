Create database student;
Qurey OK, 1 row affected (0.00 sec)

mysql> use student
Database changed

mysql> create table student(id int,name varchar(40),email varchar(80),password varchar(40));
Query OK, 0 rows affected (0.05 sec)
