<?php include('server.php') ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Login::</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
         <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar">
                        <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                              <span class="icon-bar"></span>
                    </button>
                    <a href="index.html" class="navbar-brand">Enter your email id and password to login::</a>
                </div>
                <div class="collapse navbar-collapse id="mynavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="register.html"><span class="glyphicon glyphicon-user">
                                    SIGNUP</span>
                            </a></li>
                            <li><a href="login.html"><span class="glyphicon glyphicon-log-in">
                                        LOGIN</span>
                            </a></li>
                    </ul>
                </div>
            </div> 
        </nav>
    
        
        <div class="panel panel-primary">
            <div class="panel-header">
                
            </div>
            <div class="panel-body">
                <p class="text-warning">Login to check your ability::</p>
  
<form method="post" action="login.php">
    <?php include('errors.php'); ?>                                   
  <div class="form-group">
                         
    <label for="username">User Name:</label>
    <input name="username" type="text" class="form-control" id="username" placeholder="enter your username" required/>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input name="password" type="password" class="form-control" id="pwd" placeholder="enter your password" required/>
  </div>
  <div class="checkbox">
    <label><input type="checkbox"> Remember me</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form> 
  
            </div>
            <div class="panel-footer">"Don't have an account? <a href="register.html">Register"</a></div>
        </div>
      
    
        <footer style="background-color: #000;color: #fff;font-size: 14px;">
            <div class="container">
                
                <p style="text-align: center">"Copy right @ MentalHealth.All rights"</p>
                
            </div>
        </footer>
            
    </body>
</html>